# Build and test status

## Completed checks

- All application Java source files compiled successfully with JDK 17 against the official Android API 36 android.jar, including the generated coursework BuildConfig.
- The device-side database instrumentation source also compiled successfully. It has not been executed on an emulator or phone.
- Four JUnit tests passed using JUnit 4.13.2: quantity boundaries, valid names/phone numbers, positive-to-zero stock transitions, and salted password hashing/verification.
- Main and Play manifests, vector icon, strings, and theme XML parsed successfully.
- Source formatting was normalized with google-java-format.

## Build limitation on this host

The Gradle coursework APK build reached resource linking, where the official Windows AAPT2 executable exited with access violation 0xC0000005. The Maven-provided AAPT2 and SDK Build Tools 36.0.0 executable both failed. A minimal independent Android manifest with no app resources also reproduced the native crash. This does not establish that the app can be packaged successfully elsewhere; a complete Android Studio build is still required.

Skipping that resource task allowed Gradle's Java compilation task to succeed, but Gradle's unit-test pipeline then required outputs from the skipped resource task. The four reported unit tests were therefore compiled and executed directly with javac and JUnit, not reported as a successful full Gradle test run. A subsequent full-source javac check also passed after the final code changes.

No APK is included. No emulator, physical-device, live SMS, or final Android lint results are claimed. Follow TESTING.md and run a normal build in Android Studio before submission. Fix any build, lint, or runtime issues found there. Do not represent the project as error-free solely because Java compilation passed.

## Launch document

The Word document was reopened and its structural settings verified: 12-point Times New Roman, double spacing, US Letter paper, one-inch margins, and two explicit page breaks for a planned three-page document. The document renderer is unavailable on this host (no LibreOffice runtime; Word automation denied), so final pagination and visual layout have not been verified. Open it in Word and check the 2–3 page limit before submission.

The launch plan is named for StockKeeper, as requested. Rename the file to include your student name if your instructor requires that filename convention.
