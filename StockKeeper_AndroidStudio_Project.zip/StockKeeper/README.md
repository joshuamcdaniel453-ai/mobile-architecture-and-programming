# StockKeeper — CS 360 Project Three

A new Java inventory project created because no Project Two UI project was available. Native Android activities build the views in Java. SQLite stores users, inventory items, and per-user alert preferences. The database starts empty, with no sample account or default password.

## Open in Android Studio
1. Extract the submitted ZIP fully. Open the **StockKeeper** folder containing settings.gradle, not just its app folder.
2. Use a recent Android Studio supporting Android Gradle Plugin 8.13.0. Set Gradle JDK to JDK 17. The included Gradle wrapper downloads Gradle 8.13.
3. Install Android SDK Platform 36 and the required build tools in SDK Manager. Let Studio create local.properties for your own SDK path; no machine-specific path is included in this ZIP.
4. Sync Gradle. In Build Variants, choose **courseworkDebug** for the assignment’s SMS requirement.
5. Create a phone emulator (Android 8/API 26 or newer; Android 16/API 36 recommended for the first run). Click Run. An emulator’s simulated SMS behavior does not prove carrier delivery to a physical phone.

## Build commands
Windows: `gradlew.bat assembleCourseworkDebug testCourseworkDebugUnitTest lintCourseworkDebug`
macOS/Linux: `chmod +x gradlew` then `./gradlew assembleCourseworkDebug testCourseworkDebugUnitTest lintCourseworkDebug`
Debug APK location: app/build/outputs/apk/coursework/debug/app-coursework-debug.apk
Emulator database test: `gradlew.bat connectedCourseworkDebugAndroidTest`
Play-oriented variant: `gradlew.bat assemblePlayDebug`. It removes SEND_SMS and disables texting; a production notification replacement is a future launch task, not an implemented feature.

## Using the app
- Create an account with a unique 3–32 character username (letters/numbers/underscore/dot/dash) and 8–128 character password. Usernames are case-insensitive; passwords are case-sensitive.
- Sign in and add items. Grid cards show name, quantity and a text stock status. Use +/− for one-unit changes, Edit for name/quantity, and Delete with confirmation.
- Open Alerts, enter your own permitted test recipient (7–15 digits, optional +), and choose Save number and enable SMS. The explanation and Android permission prompt are optional; denying does not block inventory.
- An alert is requested only on a positive-to-zero change or creation at zero. Setting an already-zero item to zero again does not repeat the alert. Deleting an item does not send an alert.
- Android, carrier, SIM and recipient determine actual delivery. A device “sent” result is not recipient-delivery confirmation. Settings are per account. Check runtime permission before each send.
- Sign out to switch accounts. Database data persists, but the authenticated session is process-local: closing/killing the process requires sign-in again. There is no password-reset, export, or cloud-sync feature yet. Uninstall removes local data; backups are disabled.

## Architecture
- LoginActivity: account creation, sign-in and worker-thread password checks.
- PasswordHasher: per-user random salt and PBKDF2-HMAC-SHA256, 210,000 iterations, constant-time comparison.
- InventoryDatabase: three SQLite tables, foreign keys, parameterized queries, per-user filtering, transactions and quantity constraints.
- InventoryActivity: grid, empty state, CRUD and zero-stock triggers. Database work uses one worker executor.
- SettingsActivity / SmsAlerts / SmsSentReceiver: optional runtime permission, account preferences and send-result feedback. Non-login screens are not exported.
- InventoryRules: shared validation and testable stock-transition logic.
- BaseActivity: sizing, insets for keyboard/system bars, and asynchronous UI callbacks.

## Data model
users(_id, username UNIQUE, salt, password_hash, iterations)
items(_id, user_id REFERENCES users, name, quantity CHECK 0..999999)
preferences(user_id REFERENCES users PRIMARY KEY, phone, sms_enabled)

All item reads and writes filter by user_id. No plaintext passwords, prefilled credentials, analytics, advertising SDKs, or internet permission are included. This local login is not an enterprise authorization system and does not protect data on a rooted or compromised device.

## Submission notes
Submit the source ZIP and StockKeeper_Inventory_Launch_Plan.docx. If the instructor requires your personal name in the Word filename, rename it before submission. StockKeeper is the app name, not a personal name. Incorporate any instructor feedback from earlier assignments if available. Review the included TESTING.md for actual validation results and remaining emulator tasks. AI assistance was used in code and documentation; follow course disclosure rules.
