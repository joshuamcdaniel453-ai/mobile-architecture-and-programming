# Validation and emulator checklist

Do not mark the following manual checks complete until you run them. Build/test results are recorded separately in BUILD_STATUS.md.

| Check | Procedure | Expected result |
|---|---|---|
| Empty database | Fresh install, create account | No inventory items; empty state visible |
| Registration | Valid username/password; then duplicate username | First account created; duplicate rejected |
| Invalid login | Wrong password, unknown username, blank inputs | No access; understandable feedback |
| CRUD | Add Bolts quantity 2; edit to 5; delete with confirmation | Grid and database match each action |
| Bounds | Try negative, decimal, text, blank, and over 999999 quantities | Invalid input rejected |
| Persistence | Add item, force-stop, reopen and sign in | Item remains; session requires sign-in |
| Isolation | Create account B | B cannot view or modify A’s items/settings |
| SMS denied | Enter test number, request permission, choose Deny | Inventory remains usable; no SMS |
| SMS granted | Use a permitted emulator test number, grant SMS; reduce 1 to 0 | Send attempted; result feedback; item saved |
| Duplicate alert | Save same zero item again | No additional text |
| New zero | Create item quantity 0 with SMS enabled | One alert request |
| Replenishment | Change 0 to 1, then 1 to 0 | A new alert request |
| Revocation | Revoke SMS in Android settings; return and reduce stock to zero | No crash; inventory saved; no SMS |
| Missing SIM / Wi-Fi tablet | Trigger alert | No unsupported-device crash; inventory saved |
| Lifecycle | Rotate login/settings/grid and background/restore | Usable screen and correct account; no overlapping system bars |
| Accessibility | TalkBack, larger font, narrow/wide displays | Readable labels and operable controls |
| Play variant | Inspect merged manifest and open Alerts | No SEND_SMS permission or runtime prompt |

For carrier tests, use a physical phone with a working SIM and a recipient who has consented. This project does not include a real recipient number. Sending messages may incur carrier charges. No messages were sent during source development.
