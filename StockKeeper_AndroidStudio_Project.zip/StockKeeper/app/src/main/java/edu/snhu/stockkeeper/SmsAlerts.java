package edu.snhu.stockkeeper;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import java.util.concurrent.atomic.AtomicInteger;

/** Sends only after explicit opt-in and a database-confirmed zero-stock event. */
public final class SmsAlerts {
  private static final AtomicInteger REQUESTS = new AtomicInteger(1);

  private SmsAlerts() {}

  public static String send(
      Context context, InventoryDatabase.AlertPreferences preferences, String name) {
    if (!BuildConfig.DIRECT_SMS_SUPPORTED
        || !preferences.enabled
        || context.checkSelfPermission(Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED)
      return "Item is out of stock. SMS is off; inventory saved.";
    if (!InventoryRules.validPhone(preferences.phone))
      return "Inventory saved. Add a valid SMS number in Alerts.";
    String feature =
        Build.VERSION.SDK_INT >= 33
            ? PackageManager.FEATURE_TELEPHONY_MESSAGING
            : PackageManager.FEATURE_TELEPHONY;
    if (!context.getPackageManager().hasSystemFeature(feature))
      return "Inventory saved. This device cannot send SMS.";
    try {
      // ASCII-only, bounded text stays within one standard SMS segment.
      String safe = name.replaceAll("[^A-Za-z0-9 ._-]", "?");
      if (safe.length() > 60) safe = safe.substring(0, 60);
      Intent result =
          new Intent(context, SmsSentReceiver.class).setAction("edu.snhu.stockkeeper.SMS_SENT");
      PendingIntent sent =
          PendingIntent.getBroadcast(
              context,
              REQUESTS.getAndIncrement(),
              result,
              PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
      SmsManager manager = context.getSystemService(SmsManager.class);
      if (manager == null) return "Inventory saved. SMS service unavailable.";
      manager.sendTextMessage(
          preferences.phone, null, "StockKeeper: " + safe + " is out of stock (0).", sent, null);
      return "Inventory saved. SMS submitted; waiting for device result.";
    } catch (SecurityException | IllegalArgumentException | UnsupportedOperationException error) {
      return "Inventory saved. SMS unavailable; check permission, SIM, and recipient.";
    }
  }
}
