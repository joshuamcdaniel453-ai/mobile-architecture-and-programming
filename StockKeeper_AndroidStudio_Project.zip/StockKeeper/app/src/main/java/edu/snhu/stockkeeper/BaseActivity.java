package edu.snhu.stockkeeper;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Shared spacing, system-bar handling, and asynchronous database work. */
public abstract class BaseActivity extends Activity {
  protected static final ExecutorService WORK = Executors.newSingleThreadExecutor();
  protected final Handler main = new Handler(Looper.getMainLooper());

  protected int dp(int value) {
    return Math.round(value * getResources().getDisplayMetrics().density);
  }

  protected LinearLayout column() {
    LinearLayout v = new LinearLayout(this);
    v.setOrientation(LinearLayout.VERTICAL);
    return v;
  }

  protected LinearLayout row() {
    LinearLayout v = new LinearLayout(this);
    v.setOrientation(LinearLayout.HORIZONTAL);
    return v;
  }

  protected TextView text(String value, int size) {
    TextView v = new TextView(this);
    v.setText(value);
    v.setTextSize(size);
    v.setTextColor(Color.rgb(27, 47, 43));
    v.setPadding(0, dp(5), 0, dp(5));
    return v;
  }

  protected EditText field(String hint, int type) {
    EditText v = new EditText(this);
    v.setHint(hint);
    v.setContentDescription(hint);
    v.setTextSize(17);
    v.setInputType(type);
    v.setSingleLine(true);
    v.setMinHeight(dp(52));
    return v;
  }

  protected Button button(String label) {
    Button b = new Button(this);
    b.setText(label);
    b.setAllCaps(false);
    b.setMinHeight(dp(48));
    return b;
  }

  protected void root(View view) {
    int p = dp(20);
    view.setPadding(p, p, p, p);
    setContentView(view);
    if (Build.VERSION.SDK_INT >= 30) {
      getWindow().setDecorFitsSystemWindows(false);
      view.setOnApplyWindowInsetsListener(
          (v, insets) -> {
            Insets bars =
                insets.getInsets(
                    WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout()
                        | WindowInsets.Type.ime());
            v.setPadding(p + bars.left, p + bars.top, p + bars.right, p + bars.bottom);
            return insets;
          });
      view.requestApplyInsets();
    }
  }

  protected boolean requireLogin() {
    if (AppSession.id() > 0) return true;
    startActivity(
        new Intent(this, LoginActivity.class)
            .addFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_CLEAR_TASK));
    finish();
    return false;
  }

  protected void toast(String value) {
    Toast.makeText(this, value, Toast.LENGTH_LONG).show();
  }

  protected void post(Runnable action) {
    main.post(
        () -> {
          if (!isFinishing() && !isDestroyed()) action.run();
        });
  }

  protected void failure(Exception error) {
    post(
        () ->
            toast(
                error instanceof IllegalArgumentException
                    ? error.getMessage()
                    : "Unable to complete the action. Please try again."));
  }
}
