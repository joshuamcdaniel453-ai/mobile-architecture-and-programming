package edu.snhu.stockkeeper;

/** Process-local authenticated session. Restarting the app requires signing in again. */
public final class AppSession {
  private static long userId = -1;
  private static String username = "";

  private AppSession() {}

  public static void login(long id, String name) {
    userId = id;
    username = name;
  }

  public static long id() {
    return userId;
  }

  public static String username() {
    return username;
  }

  public static void logout() {
    userId = -1;
    username = "";
  }
}
