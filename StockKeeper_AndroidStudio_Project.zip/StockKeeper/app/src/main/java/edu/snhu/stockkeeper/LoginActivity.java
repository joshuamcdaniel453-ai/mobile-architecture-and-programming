package edu.snhu.stockkeeper;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import java.util.Arrays;

/** A single accessible screen supports returning users and new accounts. */
public final class LoginActivity extends BaseActivity {
  private EditText username, password;
  private Button signIn, create;
  private TextView status;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    ScrollView scroll = new ScrollView(this);
    scroll.setFillViewport(true);
    LinearLayout content = column();
    scroll.addView(content);
    content.addView(text("StockKeeper", 36));
    content.addView(text("A clearer view of your stock.", 19));
    content.addView(text("Sign in or create your account", 24));
    username =
        field(
            "Username", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
    username.setId(101);
    username.setAutofillHints(View.AUTOFILL_HINT_USERNAME);
    password =
        field("Password", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    password.setId(102);
    password.setSaveEnabled(false);
    password.setAutofillHints(View.AUTOFILL_HINT_PASSWORD);
    content.addView(username);
    content.addView(password);
    signIn = button("Sign in");
    create = button("Create account");
    signIn.setId(103);
    create.setId(104);
    content.addView(signIn);
    content.addView(create);
    status =
        text(
            "New account? Use a 3–32 character username and a password of at least 8 characters.",
            16);
    status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
    content.addView(status);
    content.addView(
        text("Your inventory stays on this device. No account or items are preloaded.", 15));
    signIn.setOnClickListener(v -> authenticate(false));
    create.setOnClickListener(v -> authenticate(true));
    root(scroll);
  }

  private void authenticate(boolean register) {
    String name = username.getText().toString().trim();
    char[] secret = password.getText().toString().toCharArray();
    if (name.isEmpty() || secret.length == 0) {
      status.setText("Enter a username and password.");
      Arrays.fill(secret, '\0');
      return;
    }
    signIn.setEnabled(false);
    create.setEnabled(false);
    status.setText(register ? "Creating account…" : "Checking credentials…");
    WORK.execute(
        () -> {
          try {
            InventoryDatabase db = InventoryDatabase.get(this);
            long id = register ? db.register(name, secret) : db.authenticate(name, secret);
            post(
                () -> {
                  signIn.setEnabled(true);
                  create.setEnabled(true);
                  password.setText("");
                  if (id < 0) {
                    status.setText("Username or password is incorrect.");
                    return;
                  }
                  AppSession.login(id, name);
                  startActivity(new Intent(this, InventoryActivity.class));
                  finish();
                });
          } catch (Exception error) {
            post(
                () -> {
                  signIn.setEnabled(true);
                  create.setEnabled(true);
                  status.setText(
                      error instanceof IllegalArgumentException
                          ? error.getMessage()
                          : "Could not access your account. Please try again.");
                });
          } finally {
            Arrays.fill(secret, '\0');
          }
        });
  }
}
