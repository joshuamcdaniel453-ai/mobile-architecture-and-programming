package edu.snhu.stockkeeper;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Store salted, iterated password hashes, never plaintext passwords. */
public final class PasswordHasher {
  public static final int ITERATIONS = 210000;

  private PasswordHasher() {}

  public static byte[] salt() {
    byte[] salt = new byte[16];
    new SecureRandom().nextBytes(salt);
    return salt;
  }

  public static byte[] hash(char[] password, byte[] salt, int iterations) {
    PBEKeySpec spec = new PBEKeySpec(password, salt, iterations, 256);
    try {
      return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
    } catch (GeneralSecurityException error) {
      throw new IllegalStateException("Password protection is unavailable on this device.", error);
    } finally {
      spec.clearPassword();
    }
  }

  public static boolean matches(char[] password, byte[] salt, int iterations, byte[] expected) {
    byte[] actual = hash(password, salt, iterations);
    try {
      return MessageDigest.isEqual(actual, expected);
    } finally {
      Arrays.fill(actual, (byte) 0);
    }
  }
}
