package edu.snhu.stockkeeper;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;

/** SMS is opt-in. Denial, permanent denial, and revocation never block inventory. */
public final class SettingsActivity extends BaseActivity {
  private static final int SMS_REQUEST = 50;
  private EditText phone;
  private TextView status;
  private Button enable, disable;
  private long userId;

  @Override
  public void onCreate(Bundle state) {
    super.onCreate(state);
    if (!requireLogin()) return;
    userId = AppSession.id();
    ScrollView scroll = new ScrollView(this);
    LinearLayout box = column();
    scroll.addView(box);
    box.addView(text("Alert settings", 30));
    box.addView(text("Optional SMS alerts", 22));
    box.addView(
        text(
            "When an item reaches zero, StockKeeper can text the number you choose. Carrier charges"
                + " may apply. Your inventory works normally if you decline.",
            17));
    phone = field("Recipient phone number", InputType.TYPE_CLASS_PHONE);
    phone.setId(401);
    box.addView(phone);
    box.addView(text("Use 7–15 digits, optionally starting with + and your country code.", 15));
    status = text("Loading settings…", 17);
    status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
    box.addView(status);
    enable = button("Save number and enable SMS");
    disable = button("Disable SMS");
    enable.setId(402);
    disable.setId(403);
    box.addView(enable);
    box.addView(disable);
    Button back = button("Back to inventory");
    box.addView(back);
    back.setOnClickListener(v -> finish());
    enable.setOnClickListener(v -> requestSms());
    disable.setOnClickListener(v -> store(false));
    enable.setEnabled(false);
    disable.setEnabled(false);
    WORK.execute(
        () -> {
          try {
            InventoryDatabase.AlertPreferences p = InventoryDatabase.get(this).preferences(userId);
            post(
                () -> {
                  phone.setText(p.phone);
                  enable.setEnabled(BuildConfig.DIRECT_SMS_SUPPORTED);
                  disable.setEnabled(true);
                  showStatus(p.enabled);
                });
          } catch (Exception e) {
            failure(e);
          }
        });
    root(scroll);
  }

  private String recipient() {
    return phone.getText().toString().replaceAll("[\\s()\\-]", "");
  }

  private void requestSms() {
    if (!BuildConfig.DIRECT_SMS_SUPPORTED) {
      status.setText("This distribution does not request SMS permission.");
      return;
    }
    if (!InventoryRules.validPhone(recipient())) {
      phone.setError("Enter a valid recipient number.");
      return;
    }
    if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
      store(true);
      return;
    }
    new AlertDialog.Builder(this)
        .setTitle("Allow zero-stock texts?")
        .setMessage(
            "StockKeeper needs SMS permission only to send your optional out-of-stock alerts. You"
                + " can continue without it. If Android no longer shows a permission prompt, enable"
                + " SMS in system app settings or keep it disabled.")
        .setNegativeButton("Not now", (d, w) -> store(false))
        .setPositiveButton(
            "Continue",
            (d, w) -> requestPermissions(new String[] {Manifest.permission.SEND_SMS}, SMS_REQUEST))
        .show();
  }

  @Override
  public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
    super.onRequestPermissionsResult(requestCode, permissions, results);
    if (requestCode == SMS_REQUEST)
      store(results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED);
  }

  private void store(boolean enabled) {
    String number = recipient();
    if (enabled && !InventoryRules.validPhone(number)) {
      phone.setError("Enter a valid recipient number.");
      return;
    }
    enable.setEnabled(false);
    disable.setEnabled(false);
    WORK.execute(
        () -> {
          try {
            InventoryDatabase.get(this).savePreferences(userId, number, enabled);
            post(
                () -> {
                  enable.setEnabled(BuildConfig.DIRECT_SMS_SUPPORTED);
                  disable.setEnabled(true);
                  showStatus(enabled);
                });
          } catch (Exception e) {
            post(
                () -> {
                  enable.setEnabled(BuildConfig.DIRECT_SMS_SUPPORTED);
                  disable.setEnabled(true);
                });
            failure(e);
          }
        });
  }

  private void showStatus(boolean saved) {
    boolean permitted =
        checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    status.setText(
        !BuildConfig.DIRECT_SMS_SUPPORTED
            ? "SMS is unavailable in the Play distribution. Inventory remains fully functional."
            : saved && permitted
                ? "SMS enabled. A text is requested only when stock becomes zero."
                : "SMS disabled. All inventory features remain available.");
  }
}
