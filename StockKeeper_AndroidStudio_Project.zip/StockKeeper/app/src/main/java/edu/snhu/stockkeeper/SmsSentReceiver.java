package edu.snhu.stockkeeper;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/** Sent confirmation is distinct from delivery to the recipient's handset. */
public final class SmsSentReceiver extends BroadcastReceiver {
  @Override
  public void onReceive(Context context, Intent intent) {
    String result =
        getResultCode() == Activity.RESULT_OK
            ? "SMS sent by device. Recipient delivery is not confirmed."
            : "SMS could not be sent. Your inventory is still saved.";
    Toast.makeText(context, result, Toast.LENGTH_LONG).show();
  }
}
