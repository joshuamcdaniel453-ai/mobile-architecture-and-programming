package edu.snhu.stockkeeper;

/** Pure validation and alert rules shared by the UI and database layer. */
public final class InventoryRules {
  public static final int MAX_QUANTITY = 999999;

  private InventoryRules() {}

  public static int parseQuantity(String input) {
    try {
      int result = Integer.parseInt(input.trim());
      if (result < 0 || result > MAX_QUANTITY) throw new NumberFormatException();
      return result;
    } catch (NumberFormatException error) {
      throw new IllegalArgumentException("Enter a quantity from 0 to 999999.");
    }
  }

  public static String itemName(String raw) {
    String result = raw.trim();
    if (result.isEmpty() || result.length() > 80)
      throw new IllegalArgumentException("Item name must contain 1 to 80 characters.");
    return result;
  }

  public static boolean becameEmpty(int before, int after) {
    return before > 0 && after == 0;
  }

  public static boolean validPhone(String phone) {
    return phone != null && phone.matches("\\+?[0-9]{7,15}");
  }
}
