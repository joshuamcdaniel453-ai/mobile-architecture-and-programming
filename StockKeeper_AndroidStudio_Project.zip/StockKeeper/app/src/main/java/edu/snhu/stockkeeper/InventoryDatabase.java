package edu.snhu.stockkeeper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Persistent database shell. Every inventory query includes the owning user ID. */
public final class InventoryDatabase extends SQLiteOpenHelper {
  private static volatile InventoryDatabase instance;

  public static InventoryDatabase get(Context context) {
    if (instance == null)
      synchronized (InventoryDatabase.class) {
        if (instance == null) instance = new InventoryDatabase(context.getApplicationContext());
      }
    return instance;
  }

  private InventoryDatabase(Context context) {
    super(context, "stockkeeper.db", null, 1);
  }

  @Override
  public void onConfigure(SQLiteDatabase db) {
    db.setForeignKeyConstraintsEnabled(true);
  }

  @Override
  public void onCreate(SQLiteDatabase db) {
    db.execSQL(
        "CREATE TABLE users (_id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,"
            + " salt BLOB NOT NULL, password_hash BLOB NOT NULL, iterations INTEGER NOT NULL)");
    db.execSQL(
        "CREATE TABLE items (_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL"
            + " REFERENCES users(_id) ON DELETE CASCADE, name TEXT NOT NULL"
            + " CHECK(length(trim(name)) BETWEEN 1 AND 80), quantity INTEGER NOT NULL"
            + " CHECK(quantity BETWEEN 0 AND 999999))");
    db.execSQL("CREATE INDEX items_owner ON items(user_id)");
    db.execSQL(
        "CREATE TABLE preferences (user_id INTEGER PRIMARY KEY REFERENCES users(_id) ON DELETE"
            + " CASCADE, phone TEXT NOT NULL DEFAULT '', sms_enabled INTEGER NOT NULL DEFAULT 0"
            + " CHECK(sms_enabled IN (0,1)))");
  }

  @Override
  public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    throw new IllegalStateException(
        "A database migration is required; user data will not be deleted.");
  }

  public long register(String rawUsername, char[] password) {
    String username = rawUsername.trim().toLowerCase(Locale.ROOT);
    if (!username.matches("[a-z0-9_.-]{3,32}"))
      throw new IllegalArgumentException(
          "Username: use 3–32 letters, numbers, dots, dashes, or underscores.");
    if (password.length < 8 || password.length > 128)
      throw new IllegalArgumentException("Password must contain 8–128 characters.");
    byte[] salt = PasswordHasher.salt();
    ContentValues values = new ContentValues();
    values.put("username", username);
    values.put("salt", salt);
    values.put("password_hash", PasswordHasher.hash(password, salt, PasswordHasher.ITERATIONS));
    values.put("iterations", PasswordHasher.ITERATIONS);
    SQLiteDatabase db = getWritableDatabase();
    db.beginTransaction();
    try {
      long id = db.insertWithOnConflict("users", null, values, SQLiteDatabase.CONFLICT_IGNORE);
      if (id == -1) throw new IllegalArgumentException("That username is already taken.");
      ContentValues preferences = new ContentValues();
      preferences.put("user_id", id);
      db.insertOrThrow("preferences", null, preferences);
      db.setTransactionSuccessful();
      return id;
    } finally {
      db.endTransaction();
    }
  }

  public long authenticate(String rawUsername, char[] password) {
    String username = rawUsername.trim().toLowerCase(Locale.ROOT);
    try (Cursor c =
        getReadableDatabase()
            .query(
                "users",
                new String[] {"_id", "salt", "password_hash", "iterations"},
                "username=?",
                new String[] {username},
                null,
                null,
                null)) {
      if (!c.moveToFirst()) return -1;
      return PasswordHasher.matches(password, c.getBlob(1), c.getInt(3), c.getBlob(2))
          ? c.getLong(0)
          : -1;
    }
  }

  public boolean userExists(long userId) {
    try (Cursor c =
        getReadableDatabase()
            .rawQuery("SELECT 1 FROM users WHERE _id=?", new String[] {Long.toString(userId)})) {
      return c.moveToFirst();
    }
  }

  public List<Item> items(long userId) {
    List<Item> results = new ArrayList<>();
    try (Cursor c =
        getReadableDatabase()
            .query(
                "items",
                new String[] {"_id", "name", "quantity"},
                "user_id=?",
                new String[] {Long.toString(userId)},
                null,
                null,
                "name COLLATE NOCASE, _id")) {
      while (c.moveToNext()) results.add(new Item(c.getLong(0), c.getString(1), c.getInt(2)));
    }
    return results;
  }

  /** Return true only for a new zero item or a positive-to-zero transition. */
  public boolean save(long userId, Long itemId, String rawName, int quantity) {
    String name = InventoryRules.itemName(rawName);
    if (quantity < 0 || quantity > InventoryRules.MAX_QUANTITY)
      throw new IllegalArgumentException("Quantity out of range.");
    SQLiteDatabase db = getWritableDatabase();
    db.beginTransaction();
    try {
      int previous = -1;
      if (itemId != null) {
        try (Cursor c =
            db.rawQuery(
                "SELECT quantity FROM items WHERE _id=? AND user_id=?",
                new String[] {itemId.toString(), Long.toString(userId)})) {
          if (!c.moveToFirst()) throw new IllegalArgumentException("Item no longer exists.");
          previous = c.getInt(0);
        }
      }
      ContentValues v = new ContentValues();
      v.put("name", name);
      v.put("quantity", quantity);
      if (itemId == null) {
        v.put("user_id", userId);
        db.insertOrThrow("items", null, v);
      } else
        db.update(
            "items",
            v,
            "_id=? AND user_id=?",
            new String[] {itemId.toString(), Long.toString(userId)});
      db.setTransactionSuccessful();
      return quantity == 0 && (previous == -1 || InventoryRules.becameEmpty(previous, quantity));
    } finally {
      db.endTransaction();
    }
  }

  public void delete(long userId, long itemId) {
    getWritableDatabase()
        .delete(
            "items",
            "_id=? AND user_id=?",
            new String[] {Long.toString(itemId), Long.toString(userId)});
  }

  public AlertPreferences preferences(long userId) {
    try (Cursor c =
        getReadableDatabase()
            .rawQuery(
                "SELECT phone,sms_enabled FROM preferences WHERE user_id=?",
                new String[] {Long.toString(userId)})) {
      return c.moveToFirst()
          ? new AlertPreferences(c.getString(0), c.getInt(1) == 1)
          : new AlertPreferences("", false);
    }
  }

  public void savePreferences(long userId, String phone, boolean enabled) {
    ContentValues v = new ContentValues();
    v.put("phone", phone);
    v.put("sms_enabled", enabled ? 1 : 0);
    getWritableDatabase()
        .update("preferences", v, "user_id=?", new String[] {Long.toString(userId)});
  }

  public static final class AlertPreferences {
    public final String phone;
    public final boolean enabled;

    AlertPreferences(String phone, boolean enabled) {
      this.phone = phone;
      this.enabled = enabled;
    }
  }
}
