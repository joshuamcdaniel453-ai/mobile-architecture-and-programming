package edu.snhu.stockkeeper;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

/** Adaptive two-or-more-column inventory grid and account-scoped CRUD actions. */
public final class InventoryActivity extends BaseActivity {
  private final List<Item> items = new ArrayList<>();
  private GridView grid;
  private BaseAdapter adapter;
  private TextView summary, empty;
  private long userId;
  private boolean mutating;

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    if (!requireLogin()) return;
    userId = AppSession.id();
    LinearLayout content = column();
    content.addView(text("StockKeeper", 32));
    content.addView(text("Inventory • " + AppSession.username(), 17));
    LinearLayout actions = row();
    Button add = button("Add item"), settings = button("Alerts"), logout = button("Sign out");
    add.setId(201);
    settings.setId(202);
    logout.setId(203);
    for (Button b : new Button[] {add, settings, logout})
      actions.addView(b, new LinearLayout.LayoutParams(0, dp(52), 1));
    content.addView(actions);
    summary = text("Loading inventory…", 17);
    content.addView(summary);
    empty = text("No inventory yet. Tap Add item to create your first entry.", 20);
    content.addView(empty);
    grid = new GridView(this);
    grid.setId(204);
    grid.setNumColumns(2);
    grid.setHorizontalSpacing(dp(10));
    grid.setVerticalSpacing(dp(10));
    grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
    grid.addOnLayoutChangeListener(
        (v, l, t, r, b, ol, ot, or, ob) -> {
          int columns = Math.max(2, (r - l) / dp(180));
          if (grid.getNumColumns() != columns) grid.setNumColumns(columns);
        });
    adapter =
        new BaseAdapter() {
          @Override
          public int getCount() {
            return items.size();
          }

          @Override
          public Object getItem(int p) {
            return items.get(p);
          }

          @Override
          public long getItemId(int p) {
            return items.get(p).id;
          }

          @Override
          public View getView(int position, View reused, ViewGroup parent) {
            return card(items.get(position));
          }
        };
    grid.setAdapter(adapter);
    content.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
    add.setOnClickListener(v -> edit(null));
    settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    logout.setOnClickListener(
        v -> {
          AppSession.logout();
          startActivity(
              new Intent(this, LoginActivity.class)
                  .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK));
          finish();
        });
    root(content);
  }

  @Override
  protected void onResume() {
    super.onResume();
    if (requireLogin()) load();
  }

  private void load() {
    WORK.execute(
        () -> {
          try {
            List<Item> result = InventoryDatabase.get(this).items(userId);
            post(
                () -> {
                  items.clear();
                  items.addAll(result);
                  adapter.notifyDataSetChanged();
                  empty.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
                  long zeros = items.stream().filter(item -> item.quantity == 0).count();
                  summary.setText(items.size() + " items • " + zeros + " out of stock");
                });
          } catch (Exception e) {
            failure(e);
          }
        });
  }

  private View card(Item item) {
    LinearLayout box = column();
    box.setPadding(dp(12), dp(8), dp(12), dp(8));
    box.setBackgroundColor(Color.WHITE);
    TextView name = text(item.name, 19);
    name.setMaxLines(3);
    box.addView(name);
    TextView quantity = text(Integer.toString(item.quantity), 32);
    box.addView(quantity);
    TextView state = text(item.quantity == 0 ? "OUT OF STOCK" : "IN STOCK", 12);
    state.setTextColor(item.quantity == 0 ? Color.rgb(169, 45, 36) : Color.rgb(23, 107, 91));
    box.addView(state);
    LinearLayout change = row();
    Button minus = button("−"), plus = button("+");
    minus.setContentDescription("Decrease quantity of " + item.name);
    plus.setContentDescription("Increase quantity of " + item.name);
    minus.setEnabled(item.quantity > 0);
    plus.setEnabled(item.quantity < InventoryRules.MAX_QUANTITY);
    change.addView(minus, new LinearLayout.LayoutParams(0, dp(48), 1));
    change.addView(plus, new LinearLayout.LayoutParams(0, dp(48), 1));
    box.addView(change);
    Button edit = button("Edit"), delete = button("Delete");
    box.addView(edit);
    box.addView(delete);
    edit.setContentDescription("Edit " + item.name);
    delete.setContentDescription("Delete " + item.name);
    minus.setOnClickListener(v -> save(item, item.name, item.quantity - 1, null));
    plus.setOnClickListener(v -> save(item, item.name, item.quantity + 1, null));
    edit.setOnClickListener(v -> edit(item));
    delete.setOnClickListener(
        v ->
            new AlertDialog.Builder(this)
                .setTitle("Delete item?")
                .setMessage(item.name + " will be permanently removed.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> remove(item))
                .show());
    return box;
  }

  private void edit(Item item) {
    LinearLayout form = column();
    form.setPadding(dp(24), dp(8), dp(24), dp(8));
    EditText name =
        field("Item name", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
    EditText quantity = field("Quantity", InputType.TYPE_CLASS_NUMBER);
    name.setId(301);
    quantity.setId(302);
    name.setText(item == null ? "" : item.name);
    quantity.setText(item == null ? "0" : Integer.toString(item.quantity));
    form.addView(name);
    form.addView(quantity);
    AlertDialog dialog =
        new AlertDialog.Builder(this)
            .setTitle(item == null ? "Add inventory item" : "Edit inventory item")
            .setView(form)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save", null)
            .create();
    dialog.setOnShowListener(
        v ->
            dialog
                .getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(
                    w -> {
                      try {
                        String label = InventoryRules.itemName(name.getText().toString());
                        int count = InventoryRules.parseQuantity(quantity.getText().toString());
                        save(item, label, count, dialog);
                      } catch (IllegalArgumentException error) {
                        toast(error.getMessage());
                      }
                    }));
    dialog.show();
  }

  private void save(Item item, String name, int quantity, AlertDialog dialog) {
    if (mutating) return;
    mutating = true;
    if (dialog != null) dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
    WORK.execute(
        () -> {
          try {
            InventoryDatabase db = InventoryDatabase.get(this);
            boolean alert = db.save(userId, item == null ? null : item.id, name, quantity);
            InventoryDatabase.AlertPreferences prefs = db.preferences(userId);
            post(
                () -> {
                  mutating = false;
                  if (dialog != null) dialog.dismiss();
                  load();
                  if (alert) toast(SmsAlerts.send(this, prefs, name));
                });
          } catch (Exception error) {
            post(
                () -> {
                  mutating = false;
                  if (dialog != null)
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                });
            failure(error);
          }
        });
  }

  private void remove(Item item) {
    if (mutating) return;
    mutating = true;
    WORK.execute(
        () -> {
          try {
            InventoryDatabase.get(this).delete(userId, item.id);
            post(
                () -> {
                  mutating = false;
                  load();
                });
          } catch (Exception error) {
            post(() -> mutating = false);
            failure(error);
          }
        });
  }
}
