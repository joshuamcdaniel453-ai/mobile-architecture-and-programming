package edu.snhu.stockkeeper;

import android.app.Instrumentation;
import java.util.UUID;

/** Run on an emulator/device; tests create isolated accounts with unique names. */
public final class DatabaseTest extends Instrumentation {
  @Override
  public void onCreate(android.os.Bundle arguments) {
    super.onCreate(arguments);
    start();
  }

  @Override
  public void onStart() {
    android.os.Bundle result = new android.os.Bundle();
    try {
      testAccountsCrudAndIsolation();
      result.putString(
          "stream", "Database CRUD, authentication, and account-isolation checks passed.");
      finish(-1, result);
    } catch (Throwable error) {
      result.putString("stream", error.toString());
      finish(0, result);
    }
  }

  private void assertEquals(long expected, long actual) {
    if (expected != actual) throw new AssertionError(expected + " != " + actual);
  }

  private void assertEquals(String expected, String actual) {
    if (!expected.equals(actual)) throw new AssertionError(expected + " != " + actual);
  }

  private void assertTrue(boolean value) {
    if (!value) throw new AssertionError("Expected true");
  }

  private void assertFalse(boolean value) {
    if (value) throw new AssertionError("Expected false");
  }

  public void testAccountsCrudAndIsolation() {
    InventoryDatabase db = InventoryDatabase.get(getTargetContext());
    String suffix = UUID.randomUUID().toString().substring(0, 8);
    long a = db.register("usera_" + suffix, "secret-123".toCharArray());
    long b = db.register("userb_" + suffix, "secret-456".toCharArray());
    assertEquals(a, db.authenticate("usera_" + suffix, "secret-123".toCharArray()));
    assertEquals(-1L, db.authenticate("usera_" + suffix, "wrong".toCharArray()));
    assertFalse(db.save(a, null, "Bolts", 2));
    assertEquals(1, db.items(a).size());
    assertEquals(0, db.items(b).size());
    Item item = db.items(a).get(0);
    assertTrue(db.save(a, item.id, "Bolts", 0));
    assertFalse(db.save(a, item.id, "Bolts", 0));
    db.delete(b, item.id);
    assertEquals(1, db.items(a).size());
    db.delete(a, item.id);
    assertEquals(0, db.items(a).size());
    assertFalse(db.preferences(a).enabled);
    db.savePreferences(a, "+15551234567", true);
    assertTrue(db.preferences(a).enabled);
    assertFalse(db.preferences(b).enabled);
    assertEquals("+15551234567", db.preferences(a).phone);
  }
}
