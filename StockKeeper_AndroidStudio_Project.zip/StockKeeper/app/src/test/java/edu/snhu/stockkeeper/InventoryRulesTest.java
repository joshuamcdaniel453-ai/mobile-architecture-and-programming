package edu.snhu.stockkeeper;

import static org.junit.Assert.*;

import org.junit.Test;

public final class InventoryRulesTest {
  @Test
  public void zeroTransitionOnly() {
    assertTrue(InventoryRules.becameEmpty(1, 0));
    assertFalse(InventoryRules.becameEmpty(0, 0));
    assertFalse(InventoryRules.becameEmpty(0, 1));
  }

  @Test
  public void quantityBounds() {
    assertEquals(0, InventoryRules.parseQuantity("0"));
    assertEquals(999999, InventoryRules.parseQuantity("999999"));
    for (String s : new String[] {"-1", "1000000", "", "2.5", "abc", "999999999999"}) {
      try {
        InventoryRules.parseQuantity(s);
        fail(s);
      } catch (IllegalArgumentException expected) {
      }
    }
  }

  @Test
  public void namesAndPhone() {
    assertEquals("Bolts", InventoryRules.itemName(" Bolts "));
    assertTrue(InventoryRules.validPhone("+15551234567"));
    assertFalse(InventoryRules.validPhone("123"));
    assertFalse(InventoryRules.validPhone("abc5551234567"));
  }

  @Test
  public void passwordHashIsSaltedAndVerified() {
    byte[] salt = PasswordHasher.salt(), salt2 = PasswordHasher.salt();
    assertFalse(java.util.Arrays.equals(salt, salt2));
    byte[] hash =
        PasswordHasher.hash("valid-secret".toCharArray(), salt, PasswordHasher.ITERATIONS);
    assertTrue(
        PasswordHasher.matches(
            "valid-secret".toCharArray(), salt, PasswordHasher.ITERATIONS, hash));
    assertFalse(
        PasswordHasher.matches(
            "wrong-secret".toCharArray(), salt, PasswordHasher.ITERATIONS, hash));
  }
}
